// Variáveis dos Sons
let somDeColisao;
let somDoPonto;
let somDaTrilha;

function preload() {

  somDeColisao = loadSound("sons/colidiu.mp3");
  somDoPonto = loadSound("sons/pontos.wav");
  somDaTrilha = loadSound("sons/trilha.mp3");
}