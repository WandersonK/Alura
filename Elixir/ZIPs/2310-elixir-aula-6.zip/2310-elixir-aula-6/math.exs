defmodule MeuModulo.Math do
    def soma(parametro1, parametro2), do: parametro1 + parametro2
end