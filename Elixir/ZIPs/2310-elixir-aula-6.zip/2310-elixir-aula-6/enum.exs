defmodule MeuModulo.Enum do
    def primeiro([]), do: nil
    def primeiro(lista), do: hd(lista)
end